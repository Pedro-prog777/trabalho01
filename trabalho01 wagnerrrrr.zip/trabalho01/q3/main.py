# Questão 3: Sistema de autenticação simples
# Usuários e senhas pré-definidos. Criar uma função para autenticar.
usuarios = {
    "admin": "1234",
    "joao": "senha123",
    "maria": "abc@2024"
}

def autenticar(usuario: str, senha: str) -> bool:
    
    return usuarios.get(usuario) == senha

def main():
    usuario = input("Usuário: ")
    senha = input("Senha: ")

    if autenticar(usuario, senha):
        print("Autenticação bem-sucedida!")
    else:
        print("Usuário ou senha incorretos.")

    main()


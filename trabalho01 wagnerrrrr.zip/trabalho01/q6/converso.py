# conversor.py

def real_para_dolar(valor: float, cotacao: float) -> float:
    
    return valor / cotacao


def dolar_para_real(valor: float, cotacao: float) -> float:
    
    return valor * cotacao


def converter(valor: float, cotacao: float, tipo: str = "real_para_dolar") -> float:
    """Converte valores entre reais e dólares.
    
    Args:
        valor (float): valor a ser convertido
        cotacao (float): cotação do dólar
        tipo (str): 'real_para_dolar' ou 'dolar_para_real' (default = 'real_para_dolar')
    """
    if tipo == "dolar_para_real":
        return dolar_para_real(valor, cotacao)
    else:  # padrão é real_para_dolar
        return real_para_dolar(valor, cotacao)

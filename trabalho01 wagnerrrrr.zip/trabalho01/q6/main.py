# Q6 - Conversor de Moedas
# main.py
from converso import converter

def main():
    valor = float(input("Digite o valor: "))
    cotacao = float(input("Digite a cotação do dólar: "))
    tipo = input("Digite o tipo de conversão (real_para_dolar/dolar_para_real): ").strip()

    resultado = converter(valor, cotacao, tipo)
    print(f"\nResultado da conversão: {resultado:.2f}")

if __name__ == "__main__":
    main()

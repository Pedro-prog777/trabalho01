# notas.py
def media(lista_notas: list) -> float:
  
    return sum(lista_notas) / len(lista_notas) if lista_notas else 0

def maior(lista_notas: list) -> float:
    
    return max(lista_notas) if lista_notas else None

def menor(lista_notas: list) -> float:
   
    return min(lista_notas) if lista_notas else None
 
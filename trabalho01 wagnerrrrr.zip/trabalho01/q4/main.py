# Questão 4 - Verificador de Números Pares e Ímpares
# Crie uma função que receba um número inteiro e retorne se ele é par ou ímpar.

def verificar_paridade(numero: int) -> str:
   
    if numero % 2 == 0:
        return "Par"
    else:
        return "Ímpar"

def main():
    numero = int(input("Digite um número: "))
    resultado = verificar_paridade(numero)
    print(f"O número {numero} é {resultado}.")

    main()

